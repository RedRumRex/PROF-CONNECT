#!/usr/bin/env bash
# Launches Chromium full-screen on the ProfConnect door display and keeps it
# alive. Started automatically at login by the autostart entry that
# install.sh creates; you can also run it by hand to test.
set -uo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="$BUNDLE_DIR/config.env"

if [[ ! -f "$CONFIG" ]]; then
  echo "start-kiosk: $CONFIG not found. Copy config.env.example to config.env first." >&2
  exit 1
fi

# shellcheck disable=SC1090
set -a; source "$CONFIG"; set +a

DISPLAY_PORT="${DISPLAY_PORT:-8080}"
TEACHER_ID="${TEACHER_ID:-1}"
DISPLAY_ROTATION="${DISPLAY_ROTATION:-normal}"

URL="http://localhost:${DISPLAY_PORT}/index.html"
URL+="?api=${API_BASE_URL}&web=${WEB_BASE_URL}&teacher=${TEACHER_ID}"

# ── Find Chromium (the binary is named differently across Pi OS releases) ──
CHROMIUM=""
for candidate in chromium-browser chromium /usr/bin/chromium-browser /usr/bin/chromium; do
  if command -v "$candidate" >/dev/null 2>&1; then CHROMIUM="$candidate"; break; fi
done
if [[ -z "$CHROMIUM" ]]; then
  echo "start-kiosk: Chromium not found. Install it with: sudo apt install -y chromium-browser" >&2
  exit 1
fi

# ── Keep the screen on (X11 only; harmless no-ops under Wayland) ──────────
if command -v xset >/dev/null 2>&1; then
  xset s off       || true   # no screensaver
  xset s noblank   || true   # never blank
  xset -dpms       || true   # no power-down
fi
if [[ "$DISPLAY_ROTATION" != "normal" ]] && command -v xrandr >/dev/null 2>&1; then
  OUTPUT="$(xrandr --query 2>/dev/null | awk '/ connected/{print $1; exit}')"
  [[ -n "$OUTPUT" ]] && xrandr --output "$OUTPUT" --rotate "$DISPLAY_ROTATION" || true
fi
# Hide the mouse pointer when idle (the page also sets cursor:none).
command -v unclutter >/dev/null 2>&1 && (unclutter -idle 0.5 -root >/dev/null 2>&1 &)

# ── Wait for the local page server to come up ─────────────────────────────
echo "start-kiosk: waiting for http://localhost:${DISPLAY_PORT} ..."
for _ in $(seq 1 60); do
  if curl -fsS -o /dev/null "http://localhost:${DISPLAY_PORT}/index.html"; then break; fi
  sleep 1
done

# ── Clear the "Chromium didn't shut down properly" bubble ─────────────────
# A power-cut Pi shows that bar across the top of the kiosk forever otherwise.
for profile in "$HOME/.config/chromium/Default" "$HOME/.config/chromium/Default"; do
  if [[ -f "$profile/Preferences" ]]; then
    sed -i 's/"exit_type":"Crashed"/"exit_type":"Normal"/; s/"exited_cleanly":false/"exited_cleanly":true/' \
      "$profile/Preferences" 2>/dev/null || true
  fi
done

echo "start-kiosk: opening $URL"

# ── Run, and restart if Chromium ever dies ────────────────────────────────
while true; do
  "$CHROMIUM" \
    --kiosk \
    --app="$URL" \
    --start-fullscreen \
    --noerrdialogs \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-features=TranslateUI,Translate \
    --disable-pinch \
    --overscroll-history-navigation=0 \
    --no-first-run \
    --fast \
    --fast-start \
    --check-for-update-interval=31536000 \
    --autoplay-policy=no-user-gesture-required \
    --user-data-dir="$HOME/.config/chromium-profconnect" \
    >/dev/null 2>&1

  echo "start-kiosk: Chromium exited, restarting in 5s..."
  sleep 5
done
