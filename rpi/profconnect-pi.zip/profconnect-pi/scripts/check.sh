#!/usr/bin/env bash
# Diagnostic for the ProfConnect door unit. Run this whenever the display
# shows "Offline", a blank panel, or the wrong professor.
#
#   ./scripts/check.sh
set -uo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="$BUNDLE_DIR/config.env"

pass() { printf '  \033[32mPASS\033[0m  %s\n' "$1"; }
fail() { printf '  \033[31mFAIL\033[0m  %s\n' "$1"; FAILED=1; }
warn() { printf '  \033[33mWARN\033[0m  %s\n' "$1"; }
FAILED=0

echo
echo "ProfConnect door unit — diagnostics"
echo "==================================="

# ── 1. Config ─────────────────────────────────────────────────────────────
echo
echo "1. Configuration"
if [[ ! -f "$CONFIG" ]]; then
  fail "config.env missing. Run: cp config.env.example config.env && nano config.env"
  exit 1
fi
# shellcheck disable=SC1090
set -a; source "$CONFIG"; set +a

DISPLAY_PORT="${DISPLAY_PORT:-8080}"

for var in API_BASE_URL WEB_BASE_URL TEACHER_ID; do
  val="${!var:-}"
  if [[ -z "$val" ]]; then
    fail "$var is empty in config.env"
  elif [[ "$val" == *YOUR-* ]]; then
    fail "$var still has the placeholder value: $val"
  else
    pass "$var = $val"
  fi
done

# ── 2. Network + backend ──────────────────────────────────────────────────
echo
echo "2. Backend reachability"
if curl -fsS --max-time 60 "${API_BASE_URL}/api/health" >/dev/null 2>&1; then
  pass "${API_BASE_URL}/api/health responds"
else
  fail "Cannot reach ${API_BASE_URL}/api/health — check the URL, the Pi's wifi, and that the backend is awake"
fi

echo
echo "3. Professor lookup (teacher_id=${TEACHER_ID})"
TEACHER_JSON="$(curl -fsS --max-time 30 "${API_BASE_URL}/api/teachers/${TEACHER_ID}" 2>/dev/null)"
if [[ -n "$TEACHER_JSON" ]]; then
  NAME="$(printf '%s' "$TEACHER_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("name") or "(no name set)")' 2>/dev/null)"
  pass "teacher_id ${TEACHER_ID} is: ${NAME:-unknown}"
else
  fail "No teacher with teacher_id=${TEACHER_ID}. List them with: curl ${API_BASE_URL}/api/teachers"
fi

echo
echo "4. Availability endpoint"
AVAIL_JSON="$(curl -fsS --max-time 30 "${API_BASE_URL}/api/availability/${TEACHER_ID}" 2>/dev/null)"
if [[ -n "$AVAIL_JSON" ]]; then
  STATUS="$(printf '%s' "$AVAIL_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status","?"))' 2>/dev/null)"
  pass "current status = ${STATUS:-?}"
else
  fail "Availability endpoint failed. If it returns 503, run the availability-persistence block at the bottom of db/schema.sql in the Supabase SQL editor."
fi

# ── 5. CORS ───────────────────────────────────────────────────────────────
echo
echo "5. CORS for the kiosk origin"
ORIGIN="http://localhost:${DISPLAY_PORT}"
ACAO="$(curl -fsS -I --max-time 30 -H "Origin: ${ORIGIN}" \
        "${API_BASE_URL}/api/availability/${TEACHER_ID}" 2>/dev/null \
        | tr -d '\r' | awk -F': ' 'tolower($1)=="access-control-allow-origin"{print $2}')"
if [[ -n "$ACAO" ]]; then
  pass "backend allows ${ORIGIN} (Access-Control-Allow-Origin: ${ACAO})"
else
  fail "Backend does NOT allow ${ORIGIN}. Add it to CORS_ORIGIN in your backend env vars and redeploy, or the page will sit on 'Offline'."
fi

# ── 6. Local page server ──────────────────────────────────────────────────
echo
echo "6. Local display server"
if curl -fsS --max-time 5 -o /dev/null "http://localhost:${DISPLAY_PORT}/index.html" 2>/dev/null; then
  pass "serving on port ${DISPLAY_PORT}"
else
  fail "Nothing on port ${DISPLAY_PORT}. Start it with: sudo systemctl start profconnect-display"
fi

# ── 7. Services ───────────────────────────────────────────────────────────
echo
echo "7. systemd services"
for svc in profconnect-display profconnect-door; do
  if ! systemctl list-unit-files "${svc}.service" >/dev/null 2>&1 \
     || [[ -z "$(systemctl list-unit-files "${svc}.service" 2>/dev/null | grep "${svc}")" ]]; then
    warn "${svc} not installed"
  elif systemctl is-active --quiet "$svc"; then
    pass "${svc} is running"
  elif [[ "$svc" == "profconnect-door" ]]; then
    warn "${svc} not running (expected if you have no GPIO button wired)"
  else
    fail "${svc} is not running — see: journalctl -u ${svc} -n 40"
  fi
done

# ── 8. Chromium ───────────────────────────────────────────────────────────
echo
echo "8. Kiosk browser"
if command -v chromium-browser >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1; then
  pass "Chromium installed"
else
  fail "Chromium missing. Install with: sudo apt install -y chromium-browser"
fi
if pgrep -f "chromium.*localhost:${DISPLAY_PORT}" >/dev/null 2>&1; then
  pass "kiosk is on screen"
else
  warn "kiosk not currently running (fine if you are on SSH with no display attached)"
fi

echo
echo "==================================="
if [[ "$FAILED" -eq 0 ]]; then
  echo "All checks passed."
else
  echo "Some checks failed — fix the FAIL lines above, then re-run this script."
fi
echo
exit "$FAILED"
