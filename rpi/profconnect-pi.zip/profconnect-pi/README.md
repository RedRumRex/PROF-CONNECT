# ProfConnect — Raspberry Pi door unit

Everything the Pi needs, in one folder. The React frontend and the FastAPI
backend are not in here on purpose: those run in the cloud, the Pi only
displays and pushes status.

## What you get

A full-screen door display showing one professor's live availability plus a
QR code that sends students straight to that professor's booking page.

- Big **AVAILABLE** (green) / **AWAY** (red) state, readable from down the corridor
- Professor name, designation, department, room number
- QR code pointing at `{WEB_BASE_URL}/appointment/{TEACHER_ID}`
- Updates within a second when the professor flips their Dashboard toggle,
  over the same socket.io `status:update` channel the website uses
- Falls back to polling if the websocket drops, and shows a Live /
  Reconnecting / Offline indicator so a stale screen is never mistaken for
  a live one
- Starts on boot, restarts if Chromium crashes, survives power cuts

Optional: if you wire a switch to a GPIO pin, the professor can flip their
own status from the door itself and the website updates instantly.

---

## Setup — 5 steps

### Step 1. Copy this folder onto the Pi

From your laptop:

```bash
scp -r profconnect-pi pi@raspberrypi.local:~/
```

Or unzip it directly on the Pi:

```bash
unzip profconnect-pi.zip -d ~/
cd ~/profconnect-pi
```

### Step 2. Find your professor's teacher_id

```bash
curl https://YOUR-BACKEND.onrender.com/api/teachers
```

Look through the output for the right professor and note their
`teacher_id`. That number identifies which door this is.

If this hangs for 30–60 seconds the first time, that's a free-tier host
cold-starting. Run it again.

### Step 3. Fill in config.env

This is the only file you edit. Everything else reads from it.

```bash
cd ~/profconnect-pi
cp config.env.example config.env
nano config.env
```

Set these three:

| Variable | What it is | Example |
| --- | --- | --- |
| `API_BASE_URL` | Your deployed FastAPI backend, no trailing slash | `https://prof-connect.onrender.com` |
| `WEB_BASE_URL` | Your deployed React site, no trailing slash | `https://profconnect.vercel.app` |
| `TEACHER_ID` | The number from step 2 | `7` |

Leave `TEACHER_EMAIL` and `TEACHER_PASSWORD` blank unless you have a
physical button wired. Save with `Ctrl+O`, `Enter`, then `Ctrl+X`.

### Step 4. Run the installer

```bash
chmod +x install.sh
./install.sh
```

Do not use `sudo` — the script asks for it only where it needs it. It
installs packages, tests your backend, creates a virtualenv, installs two
systemd services, and sets Chromium to launch on login. Safe to re-run.

### Step 5. Open CORS on your backend

**This step is on your host, not the Pi, and the display will not work
without it.** `sockets.py` passes `cors_allowed_origins=CORS_ORIGIN` and the
REST middleware uses the same list, so the backend rejects the kiosk origin
until you add it.

In your Render (or other host) environment variables, change:

```
CORS_ORIGIN=https://YOUR-SITE.vercel.app,http://localhost:8080
```

Then redeploy. Now reboot the Pi:

```bash
sudo reboot
```

The display should come up full-screen by itself.

---

## Verifying it works

```bash
cd ~/profconnect-pi
./scripts/check.sh
```

This checks eight things in order — config values, backend reachability,
that your `teacher_id` resolves to a real professor, the availability
endpoint, whether CORS actually allows the kiosk origin, the local page
server, both services, and Chromium. Every failure line tells you the fix.

To see the display without any backend at all:

```
http://localhost:8080/index.html?demo=1
```

Demo mode uses fake data and flips between available and away every 8
seconds, so you can confirm the screen, fonts, and QR render properly
before worrying about the network.

---

## Everyday commands

```bash
# Launch the kiosk right now, without rebooting
./scripts/start-kiosk.sh

# Follow the display server's log
journalctl -u profconnect-display -f

# Follow the GPIO pusher's log
journalctl -u profconnect-door -f

# Restart after editing config.env
sudo systemctl restart profconnect-display profconnect-door

# Quit the kiosk from a keyboard
Alt+F4      # or Ctrl+Alt+T for a terminal, then: pkill chromium
```

After changing `config.env`, restart the services and reload the page —
the URL is rebuilt from config on every kiosk launch.

---

## Adding a physical button later

The display alone is read-only: it shows what the professor set from the
website. To let them flip it at the door, wire a toggle switch between
**BCM 17** and **ground** (change `TOGGLE_PIN` in `config.env` for a
different pin). Closed means available.

Then fill in `TEACHER_EMAIL` and `TEACHER_PASSWORD` in `config.env` with
that professor's ProfConnect login and run:

```bash
./install.sh
sudo systemctl status profconnect-door
```

`door-unit/availability_client.py` logs in, caches the JWT to `.token`,
pushes with `PATCH /api/availability/me`, and re-logs in automatically when
the 24-hour token expires. It also polls the API so a change made from the
website is reflected back at the door.

Storing a password on the Pi is the weak point of this design. The better
long-term fix is a device-key branch in `routers/availability.py` mirroring
`_authorize()` in `professors.py`, so each Pi gets its own revocable secret.

---

## Troubleshooting

**Screen shows "Offline" and never connects.**
CORS. Run `./scripts/check.sh` — check 5 tells you directly. Add
`http://localhost:8080` to `CORS_ORIGIN` and redeploy the backend.

**"Professor #7" instead of a name.**
`GET /api/teachers/{id}` failed. Either the id doesn't exist (`curl
.../api/teachers` to list them) or `avatar_url` hasn't been migrated — the
router returns 503 with that exact message. Run the profile-photo
`alter table` statements from the main README.

**Availability endpoint returns 503.**
The `teacher.available` / `available_updated_at` columns are missing. Run
the availability-persistence block at the bottom of `db/schema.sql` in the
Supabase SQL editor.

**QR code shows a URL as text instead of a code.**
The Pi couldn't load the QR library from the CDN. It degrades to showing
the link rather than a blank box. Check the Pi's internet, or vendor
`qrcode.js` locally next to `index.html` and change the `<script src>`.

**Blank white screen.**
The page server isn't up. `sudo systemctl status profconnect-display` and
`journalctl -u profconnect-display -n 40`.

**Chromium shows a "didn't shut down properly" bar after a power cut.**
`start-kiosk.sh` already clears that flag on launch. If it persists, delete
`~/.config/chromium-profconnect` and relaunch.

**Screen goes black after 10 minutes.**
Blanking wasn't disabled. Run `sudo raspi-config` → Display Options →
Screen Blanking → No.

---

## What's in here

```
profconnect-pi/
├─ config.env.example              the only file you edit
├─ install.sh                      one-shot installer
├─ README.md                       this file
├─ door-display/
│  └─ index.html                   the full-screen display (self-contained)
├─ door-unit/
│  ├─ availability_client.py       GPIO button -> PATCH /api/availability/me
│  ├─ legacy_status_client.py      old /api/professors bridge, kept for reference
│  └─ requirements.txt
├─ scripts/
│  ├─ start-kiosk.sh               launches and babysits Chromium
│  └─ check.sh                     8-point diagnostic
└─ systemd/
   ├─ profconnect-display.service.template
   └─ profconnect-door.service.template
```

### A note on `legacy_status_client.py`

That's the original `pi-client/status_client.py` from the repo. It targets
`POST /api/professors/{slug}/status`, which the main README describes as
"a leftover from an earlier version of the product concept... nothing in
the current UI reads from it." It is keyed by fake slugs like `aris-thorne`
that don't match any real `teacher_id`, and `store.py` behind it is
in-memory so it resets on every backend restart. It's included only so you
have it; use `availability_client.py` instead.
