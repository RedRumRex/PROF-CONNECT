#!/usr/bin/env python3
"""
ProfConnect door unit -- Raspberry Pi client (real availability version).

Unlike status_client.py, which talks to the legacy /api/professors bridge
(API-key auth, in-memory store, fake seed slugs, not read by the UI), this
client drives the SAME endpoint the professor's own Dashboard toggle uses:

    POST  /api/auth/login              -> teacher JWT
    PATCH /api/availability/me         -> sets this teacher's availability
    GET   /api/availability/{id}       -> reads it back (remote-change sync)

So anything it pushes shows up live on the website for every visitor,
because the backend broadcasts it over the shared socket.io
"status:update" channel that useLiveStatus() listens to.

Note: the real availability model is a BOOLEAN (available / away). There is
no "busy" state, so the physical control here is a 2-state toggle, not the
3-button setup in status_client.py.

Config comes from ../config.env (the single file you edit for the whole
bundle), or from $PROFCONNECT_CONFIG if set. install.sh wires this up as a
systemd service; to run it by hand:

    cd door-unit
    ../.venv/bin/python availability_client.py
"""

import json
import logging
import os
import time
from pathlib import Path

import requests

try:
    import RPi.GPIO as GPIO  # noqa: N814  (only present on real hardware)
    ON_PI = True
except ImportError:
    ON_PI = False


# -- Config --------------------------------------------------------------
DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config.env"


def load_env(path=None):
    """Real environment wins; config.env fills in the rest."""
    env = dict(os.environ)
    p = Path(path or os.environ.get("PROFCONNECT_CONFIG") or DEFAULT_CONFIG)
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            v = v.strip().strip('"').strip("'")
            if v:
                env.setdefault(k.strip(), v)
    return env


ENV = load_env()

API_BASE_URL = ENV.get("API_BASE_URL", "http://localhost:4000").rstrip("/")
TEACHER_EMAIL = ENV.get("TEACHER_EMAIL", "")
TEACHER_PASSWORD = ENV.get("TEACHER_PASSWORD", "")
TEACHER_ID = ENV.get("TEACHER_ID", "")  # numeric teacher_id, used for the read-back poll
REFRESH_SECONDS = int(ENV.get("REFRESH_SECONDS", "20"))
TOGGLE_PIN = int(ENV.get("TOGGLE_PIN", "17"))  # BCM. Closed (LOW) = available.
REQUEST_TIMEOUT = 10  # generous: free-tier hosts cold-start slowly

TOKEN_CACHE = Path(__file__).resolve().parent / ".token"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("profconnect-door-unit")


# -- Hardware stubs -- replace with your real wiring --------------------
def setup_hardware():
    if not ON_PI:
        log.warning("RPi.GPIO not available -- simulation mode, no physical reads.")
        return
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(TOGGLE_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)


def read_physical_switch():
    """Return True (available) / False (away), or None if we can't read."""
    if not ON_PI:
        return None
    return GPIO.input(TOGGLE_PIN) == GPIO.LOW


def render_display(available: bool):
    """Update the door-mounted display (e-ink / OLED / LED / Chromium kiosk)."""
    log.info(f"[DISPLAY] Now showing: {'AVAILABLE' if available else 'AWAY'}")


# -- Auth ---------------------------------------------------------------
def login() -> str | None:
    """Exchange the teacher's credentials for a JWT. Cached to disk so a
    restart or reboot doesn't re-login unnecessarily."""
    try:
        resp = requests.post(
            f"{API_BASE_URL}/api/auth/login",
            json={"role": "teacher", "email": TEACHER_EMAIL, "password": TEACHER_PASSWORD},
            timeout=REQUEST_TIMEOUT,
        )
        if resp.status_code == 200:
            token = resp.json()["access_token"]
            TOKEN_CACHE.write_text(token)
            TOKEN_CACHE.chmod(0o600)
            log.info("Logged in, JWT cached.")
            return token
        log.error(f"Login failed ({resp.status_code}): {resp.text}")
    except requests.RequestException as e:
        log.error(f"Login error: {e}")
    except (KeyError, ValueError) as e:
        log.error(f"Unexpected login response: {e}")
    return None


def get_token(force_refresh: bool = False) -> str | None:
    if not force_refresh and TOKEN_CACHE.exists():
        cached = TOKEN_CACHE.read_text().strip()
        if cached:
            return cached
    return login()


# -- Networking ---------------------------------------------------------
def push_availability(available: bool) -> bool:
    """PATCH /api/availability/me, re-logging in once on a 401."""
    for attempt in (1, 2):
        token = get_token(force_refresh=(attempt == 2))
        if not token:
            return False
        try:
            resp = requests.patch(
                f"{API_BASE_URL}/api/availability/me",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                data=json.dumps({"available": available}),
                timeout=REQUEST_TIMEOUT,
            )
            if resp.status_code == 200:
                log.info(f"Pushed availability -> {'available' if available else 'away'}")
                return True
            if resp.status_code == 401 and attempt == 1:
                log.warning("Token rejected -- refreshing and retrying.")
                continue
            log.error(f"Push failed ({resp.status_code}): {resp.text}")
            return False
        except requests.RequestException as e:
            log.error(f"Push error: {e}")
            return False
    return False


def pull_availability():
    """GET /api/availability/{teacher_id} -- public, no auth needed. Lets the
    door display follow changes the professor made from the website."""
    if not TEACHER_ID:
        return None
    try:
        resp = requests.get(
            f"{API_BASE_URL}/api/availability/{TEACHER_ID}", timeout=REQUEST_TIMEOUT
        )
        if resp.status_code == 200:
            return resp.json().get("status") == "available"
        log.error(f"Pull failed ({resp.status_code}): {resp.text}")
    except requests.RequestException as e:
        log.error(f"Pull error: {e}")
    return None


# -- Main loop ----------------------------------------------------------
def main():
    if not (TEACHER_EMAIL and TEACHER_PASSWORD):
        log.error("TEACHER_EMAIL / TEACHER_PASSWORD not set in .env -- exiting.")
        return

    setup_hardware()
    log.info(f"Door unit starting -- api={API_BASE_URL}, teacher_id={TEACHER_ID or 'unset'}")

    last_known = None
    last_pull = 0.0

    while True:
        # 1) Physical control moved -> push immediately.
        physical = read_physical_switch()
        if physical is not None and physical != last_known:
            if push_availability(physical):
                last_known = physical
                render_display(physical)

        # 2) Periodic read-back, so remote changes reach the door display.
        now = time.time()
        if now - last_pull >= REFRESH_SECONDS:
            last_pull = now
            remote = pull_availability()
            if remote is not None and remote != last_known:
                last_known = remote
                render_display(remote)

        time.sleep(0.5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    finally:
        if ON_PI:
            GPIO.cleanup()
