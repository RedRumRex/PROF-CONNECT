#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────
#  ProfConnect door unit installer
#
#  Run this on the Raspberry Pi, from inside the unzipped folder:
#
#      cp config.env.example config.env
#      nano config.env            # fill in the 3 required values
#      chmod +x install.sh
#      ./install.sh
#
#  It is safe to re-run. Nothing outside this folder, /etc/systemd/system,
#  and ~/.config/autostart is touched.
# ─────────────────────────────────────────────────────────────────────────
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$BUNDLE_DIR/config.env"
RUN_USER="${SUDO_USER:-$USER}"
RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"

step()  { printf '\n\033[1;35m==>\033[0m \033[1m%s\033[0m\n' "$1"; }
info()  { printf '    %s\n' "$1"; }
ok()    { printf '    \033[32m✓\033[0m %s\n' "$1"; }
die()   { printf '\n\033[31mError:\033[0m %s\n\n' "$1" >&2; exit 1; }

[[ "$EUID" -eq 0 ]] && die "Do NOT run this with sudo. Run it as your normal user (it will ask for sudo where needed)."

echo
echo "  ProfConnect door unit installer"
echo "  ==============================="
info "bundle: $BUNDLE_DIR"
info "user:   $RUN_USER"

# ── 1. Config ─────────────────────────────────────────────────────────────
step "1/7  Checking config.env"
if [[ ! -f "$CONFIG" ]]; then
  die "config.env not found.
    Run these two commands first, then re-run ./install.sh:
      cp config.env.example config.env
      nano config.env"
fi
# shellcheck disable=SC1090
set -a; source "$CONFIG"; set +a

DISPLAY_PORT="${DISPLAY_PORT:-8080}"
: "${API_BASE_URL:?API_BASE_URL is not set in config.env}"
: "${WEB_BASE_URL:?WEB_BASE_URL is not set in config.env}"
: "${TEACHER_ID:?TEACHER_ID is not set in config.env}"

for var in API_BASE_URL WEB_BASE_URL; do
  [[ "${!var}" == *YOUR-* ]] && die "$var in config.env is still the placeholder (${!var}). Edit it with: nano config.env"
done
chmod 600 "$CONFIG"
ok "config.env looks filled in (chmod 600)"

# ── 2. Packages ───────────────────────────────────────────────────────────
step "2/7  Installing system packages"
PKGS=(python3 python3-venv python3-pip curl)
command -v chromium-browser >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1 || PKGS+=(chromium-browser)
command -v unclutter >/dev/null 2>&1 || PKGS+=(unclutter)
command -v xset >/dev/null 2>&1       || PKGS+=(x11-xserver-utils)

info "apt-get install: ${PKGS[*]}"
sudo apt-get update -qq
if ! sudo apt-get install -y -qq "${PKGS[@]}"; then
  # Pi OS Lite and some Bookworm images ship "chromium" rather than "chromium-browser".
  info "retrying with the 'chromium' package name"
  PKGS=("${PKGS[@]/chromium-browser/chromium}")
  sudo apt-get install -y -qq "${PKGS[@]}" || die "Package install failed. Run 'sudo apt-get update' and check your network."
fi
ok "packages installed"

# ── 3. Verify the backend before wiring anything up ───────────────────────
step "3/7  Testing the backend"
info "GET ${API_BASE_URL}/api/health"
if curl -fsS --max-time 90 "${API_BASE_URL}/api/health" >/dev/null 2>&1; then
  ok "backend is reachable"
else
  info "WARNING: could not reach ${API_BASE_URL}/api/health"
  info "Install will continue, but the display will show 'Offline' until this works."
  info "Free-tier hosts can take 60s to wake — try again, or check the URL."
fi

info "GET ${API_BASE_URL}/api/teachers/${TEACHER_ID}"
TEACHER_JSON="$(curl -fsS --max-time 60 "${API_BASE_URL}/api/teachers/${TEACHER_ID}" 2>/dev/null || true)"
if [[ -n "$TEACHER_JSON" ]]; then
  PROF_NAME="$(printf '%s' "$TEACHER_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("name") or "(name not set)")' 2>/dev/null || echo "?")"
  ok "this door will show: ${PROF_NAME}"
else
  info "WARNING: no teacher found for teacher_id=${TEACHER_ID}"
  info "List valid ids with:  curl ${API_BASE_URL}/api/teachers"
fi

# ── 4. Python venv for the optional GPIO client ───────────────────────────
step "4/7  Setting up the Python environment"
if [[ ! -d "$BUNDLE_DIR/.venv" ]]; then
  python3 -m venv "$BUNDLE_DIR/.venv"
fi
"$BUNDLE_DIR/.venv/bin/pip" install --quiet --upgrade pip
"$BUNDLE_DIR/.venv/bin/pip" install --quiet -r "$BUNDLE_DIR/door-unit/requirements.txt"
ok "virtualenv ready at .venv"

chmod +x "$BUNDLE_DIR/scripts/"*.sh
ok "scripts made executable"

# ── 5. systemd services ───────────────────────────────────────────────────
step "5/7  Installing systemd services"

render_unit() {
  sed -e "s|__USER__|${RUN_USER}|g" \
      -e "s|__BUNDLE_DIR__|${BUNDLE_DIR}|g" \
      -e "s|__DISPLAY_PORT__|${DISPLAY_PORT}|g" \
      "$1"
}

render_unit "$BUNDLE_DIR/systemd/profconnect-display.service.template" \
  | sudo tee /etc/systemd/system/profconnect-display.service >/dev/null
ok "profconnect-display.service (serves the page on port ${DISPLAY_PORT})"

render_unit "$BUNDLE_DIR/systemd/profconnect-door.service.template" \
  | sudo tee /etc/systemd/system/profconnect-door.service >/dev/null
ok "profconnect-door.service (GPIO button pusher)"

sudo systemctl daemon-reload
sudo systemctl enable --now profconnect-display.service >/dev/null 2>&1
ok "display server enabled and started"

if [[ -n "${TEACHER_EMAIL:-}" && -n "${TEACHER_PASSWORD:-}" ]]; then
  sudo systemctl enable --now profconnect-door.service >/dev/null 2>&1
  ok "GPIO pusher enabled (credentials found in config.env)"
else
  sudo systemctl disable profconnect-door.service >/dev/null 2>&1 || true
  info "GPIO pusher left OFF — no TEACHER_EMAIL/TEACHER_PASSWORD in config.env."
  info "That is correct if you have no physical button yet. The display works regardless."
fi

# ── 6. Kiosk autostart ────────────────────────────────────────────────────
step "6/7  Setting up Chromium kiosk autostart"
AUTOSTART_DIR="$RUN_HOME/.config/autostart"
mkdir -p "$AUTOSTART_DIR"
cat > "$AUTOSTART_DIR/profconnect-kiosk.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=ProfConnect Door Display
Comment=Full-screen professor availability display
Exec=${BUNDLE_DIR}/scripts/start-kiosk.sh
X-GNOME-Autostart-enabled=true
NoDisplay=true
DESKTOP
ok "autostart entry written to ~/.config/autostart/"

# Stop the desktop blanking the screen after 10 minutes.
if command -v raspi-config >/dev/null 2>&1; then
  sudo raspi-config nonint do_blanking 1 >/dev/null 2>&1 && ok "screen blanking disabled" || true
fi

# ── 7. Summary ────────────────────────────────────────────────────────────
step "7/7  Done"
KIOSK_URL="http://localhost:${DISPLAY_PORT}/index.html?api=${API_BASE_URL}&web=${WEB_BASE_URL}&teacher=${TEACHER_ID}"

cat <<SUMMARY

    Installed. What happens now:

      - The display page is being served on port ${DISPLAY_PORT} (starts on every boot).
      - Chromium will open it full-screen the next time the desktop logs in.

    Verify everything:      ./scripts/check.sh
    Launch the kiosk now:   ./scripts/start-kiosk.sh
    Preview in a browser:   ${KIOSK_URL}
    See the demo states:    http://localhost:${DISPLAY_PORT}/index.html?demo=1

    Logs:
      journalctl -u profconnect-display -f
      journalctl -u profconnect-door -f

    ONE THING LEFT, on your backend (not the Pi):
      Add  http://localhost:${DISPLAY_PORT}  to the CORS_ORIGIN environment
      variable and redeploy. Without it the page loads but sits on "Offline",
      because the backend rejects requests from this origin.

      e.g. CORS_ORIGIN=${WEB_BASE_URL},http://localhost:${DISPLAY_PORT}

SUMMARY
